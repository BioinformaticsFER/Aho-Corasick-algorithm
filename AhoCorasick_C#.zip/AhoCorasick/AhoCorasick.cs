/*
 * Author: Antonio Soldo
 * 
 * This code is implementation of Aho-Corasick string searching algorithm which
 * constructs a deterministic finite automata (DFA) based on given keywords.
 * Goal of this algorithm is to find all occurrences of defined keywords in a
 * given text. 
 * 
 * Input: two files, one containing keywords and other containing text
 * 
 * Output: one file, named output which stores position and what keyword
 *         was found on that position
 * 
 * */

using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

/*
 * Class Algorithm contains only main method. Its purpose is to call methods of
 * class DFA in order to define DFA and then find all occurrences of keywords
 * 
 * */
public class Algorithm
{
	/*
	 * Main function constructs DFA (using side class DFA) for defined keywords 
	 * and then finds all occurrences of them in a given text.
	 * It receives two input parameters:
	     - first parameter is name of the file containing keywords
	     - second parameter is name of the file containing text to be searched
	*/
	static public int Main(string[] args)
	{
		string keywords_path = String.Empty;
		string text_path = String.Empty;
		string[] keywords = new string[]{};
		
		
		if(args.Length == 2)
		{			
			keywords_path = args[0];
			try
			{
				using (StreamReader sr = new StreamReader(keywords_path))
				{
					char[] delimiters = new char[]{','};
					keywords = sr.ReadLine().Split(delimiters, StringSplitOptions.RemoveEmptyEntries).ToArray();
					keywords = keywords.Distinct().ToArray();
				}
				
			}
			
			catch(NullReferenceException)
			{
				Console.WriteLine("File with keywords does not exist!");
				return -1;
			}
			
			try
			{
				text_path = args[1];
			}
			
			catch(IndexOutOfRangeException)
			{
				Console.WriteLine("File with text does not exist!");
				return -1;
			}
		}
		
		else
		{
			Console.WriteLine("Given number of arguments: " + args.Length);
			Console.WriteLine("Required number of arguments: 2");
			return -1;
		}
		
		string text;
		
		Stopwatch stw = new Stopwatch();
		TimeSpan time = new TimeSpan();
		stw.Reset();
		
		DFA automata = new DFA();
		
		stw.Reset();
		
		// Constructing a DFA for pattern matching from given set of keywords
		stw.Start();
		automata.gotoFun(keywords);
		automata.failure();
		stw.Stop();
		
		time = stw.Elapsed;
		Console.WriteLine("Construction of DFA done in {0} ms.", time.TotalMilliseconds);
		
		Dictionary<Key, int> g = automata.g;
		
		List<char> alphabet = automata.alphabet;
		
		Dictionary<int, List<string>> output = automata.output;
		
		Dictionary<int, int> f = automata.f;
		
		int state = 0;
		
		stw.Reset();
		stw.Start();
		
		// Finding all occurrences of keywords in given text using previously built DFA
		int position = 0;
		
		try
		{
			using(StreamReader sr = File.OpenText(text_path))
			{
				using(StreamWriter sw = new StreamWriter(@"output"))
				{
					while((text = sr.ReadLine()) != null)
					{
						for(int i = 0; i < text.Length; i++)
						{
							int counter = 0;
							Key key = new Key(state, text[i]);
							
							if(g.ContainsKey(key))
							{
								state = g[key];
								counter = 1;
								
								if(output.ContainsKey(state))
								{
									foreach(string oi in output[state])
									{
										string print = string.Format("index: {0,7}   =>   keyword: {1,-10}",(position + i - oi.Length + 1), oi);
										sw.WriteLine(print);
									}
								}
							}
							
							if (counter == 0)
							{
								if(!alphabet.Contains(text[i]))
								{
									alphabet.Add(text[i]);
									g.Add(new Key(0, text[i]), 0);
								}
								
								if(state != 0)
								{
									int foundState = 0;
									while(foundState == 0)
									{
										state = f[state];
										Key key2 = new Key(state, text[i]);
										
										if(g.ContainsKey(key2))
										{
											foundState = 1;
											state = g[key2];
											break;
										}
									}
								}
							}
						}
						
						position += text.Length;
					}
				}
				
				stw.Stop();
				time = stw.Elapsed;
				
				Console.WriteLine("Finding all keywords in text done in {0} ms.", time.TotalMilliseconds);
				Console.WriteLine("Total memory used: {0} KiB", GC.GetTotalMemory(false)/1024);
				
				return 0;
			}
		}
		
		catch(IOException e)
		{
			Console.WriteLine("File with input text does not exist!");
			Console.WriteLine(e.Message);
			return -1;
		}
	}
}
