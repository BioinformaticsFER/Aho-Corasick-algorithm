using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

public class Algorithm
{

	static public int Main(string[] args)
	{
		string keywords_path = args[0];
		string text_path = args[1];
		
		string[] keywords = new string[]{};
		string text = "";
		
		Stopwatch stw = new Stopwatch();
		TimeSpan time = new TimeSpan();
		stw.Reset();
		
		DFA automata = new DFA();
		
		try
		{
			stw.Start();
			using (StreamReader sr = new StreamReader(keywords_path))
			{
				keywords = sr.ReadLine().Split(',').ToArray();
			}
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
		
		try
		{
			using (StreamReader sr = new StreamReader(text_path))
			{
				StringBuilder sb = new StringBuilder(sr.ReadToEnd());
				sb.Replace("\r\n", string.Empty);
				sb.Replace("\n", string.Empty);
				text = sb.ToString();
			}
			stw.Stop();
			
			
			time = stw.Elapsed;
			Console.WriteLine("Loading files done in {0} ms.", time.TotalMilliseconds);
			
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
		
		try
		{
			stw.Reset();
			
			stw.Start();
			automata.gotoFun(keywords);
			automata.failure();
			stw.Stop();
			time = stw.Elapsed;
			Console.WriteLine("Construction of DFA done in {0} ms.", time.TotalMilliseconds);
			
			Dictionary<Tuple<int, char>, int> g = automata.g;
			
			List<char> alphabet = automata.alphabet;
			
			Dictionary<int, List<string>> output = automata.output;
			
			Dictionary<int, int> f = automata.f;
			
			int state = 0;
			
			stw.Reset();
			stw.Start();
			
			using(StreamWriter sw = new StreamWriter(@"output"))
			{
				for(int i = 0; i < text.Length; i++)
				{
					if(g.ContainsKey(Tuple.Create<int, char>(state, text[i])))
					{
						state = g[Tuple.Create<int, char>(state, text[i])];
					}
					else if (state == 0)
					{
						g.Add(Tuple.Create<int, char>(0, text[i]), 0);
						alphabet.Add(text[i]);
						state = 0;
					}
					else
					{
						state = f[state];
						if (!alphabet.Contains(text[i])  && !g.ContainsKey(Tuple.Create<int, char>(0, text[i])))
						{
							g.Add(Tuple.Create<int, char>(0, text[i]), 0);
						}
						
						while (!g.ContainsKey(Tuple.Create<int, char>(state, text[i])))
						{
							state = f[state];
						}
						
						state = g[Tuple.Create<int, char>(state, text[i])];
					}
					
					if (output.ContainsKey(state))
					{
						foreach(string oi in output[state])
						{
							string print = string.Format("index: {0,7}   =>   keyword: {1,-10}",(i - oi.Length + 1), oi);
							sw.WriteLine(print);
						}
					}
				}
				stw.Stop();
				time = stw.Elapsed;
				
				Console.WriteLine("Finding all keywords in text done in {0} ms.", time.TotalMilliseconds);
				Console.WriteLine("Total memory used: {0} KiB", GC.GetTotalMemory(false)/1024);
				
				return 0;
			}
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
	}
}
