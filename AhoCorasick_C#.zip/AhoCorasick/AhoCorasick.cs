using System;
using System.Text;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Diagnostics;

public class Algorithm
{
	/*
	 * Main function constructs DFA (using side class DFA) for defined keywords 
	 * and then finds all occurrences of them in a given text.
	 * It receives two input parameters:
	     - first parameter is name of the file containing keywords
	     - second parameter is name of the file containing text to be searched
	*/
	static public int Main(string[] args)
	{
		string keywords_path = args[0];
		string text_path = args[1];
		
		string[] keywords = new string[]{};
		string text = "";
		
		Stopwatch stw = new Stopwatch();
		TimeSpan time = new TimeSpan();
		stw.Reset();
		
		DFA automata = new DFA();
		
		try
		{
			stw.Start();
			using (StreamReader sr = new StreamReader(keywords_path))
			{
				keywords = sr.ReadLine().Split(',').ToArray();
			}
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
		
		try
		{
			using (StreamReader sr = new StreamReader(text_path))
			{
				StringBuilder sb = new StringBuilder(sr.ReadToEnd());
				sb.Replace("\r\n", string.Empty);
				sb.Replace("\n", string.Empty);
				text = sb.ToString();
			}
			stw.Stop();
			
			
			time = stw.Elapsed;
			Console.WriteLine("Loading files done in {0} ms.", time.TotalMilliseconds);
			
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
		
		try
		{
			stw.Reset();
			
			// Constructing a DFA for pattern matching from given set of keywords
			stw.Start();
			automata.gotoFun(keywords);
			automata.failure();
			stw.Stop();
			time = stw.Elapsed;
			Console.WriteLine("Construction of DFA done in {0} ms.", time.TotalMilliseconds);
			
			Dictionary<Key, int> g = automata.g;
			
			List<char> alphabet = automata.alphabet;
			
			Dictionary<int, List<string>> output = automata.output;
			
			Dictionary<int, int> f = automata.f;
			
			int state = 0;
			
			stw.Reset();
			stw.Start();
			
			// Finding all occurrences of keywords in given text using DFA
			using(StreamWriter sw = new StreamWriter(@"output"))
			{
				for(int i = 0; i < text.Length; i++)
				{
					int counter = 0;
					Key key = new Key(state, text[i]);
					
					if(g.ContainsKey(key))
					{
						state = g[key];
						counter = 1;
						
						if(output.ContainsKey(state))
						{
							foreach(string oi in output[state])
							{
								string print = string.Format("index: {0,7}   =>   keyword: {1,-10}",(i - oi.Length + 1), oi);
								sw.WriteLine(print);
							}
						}
					}
					
					if (counter == 0)
					{
						if(!alphabet.Contains(text[i]))
						{
							alphabet.Add(text[i]);
							g.Add(new Key(0, text[i]), 0);
						}
						
						if(state != 0)
						{
							int foundState = 0;
							while(foundState == 0)
							{
								state = f[state];
								Key key2 = new Key(state, text[i]);
								
								if(g.ContainsKey(key2))
								{
									foundState = 1;
									state = g[key2];
									break;
								}
							}
						}
					}
				}
				stw.Stop();
				time = stw.Elapsed;
				
				Console.WriteLine("Finding all keywords in text done in {0} ms.", time.TotalMilliseconds);
				Console.WriteLine("Total memory used: {0} KiB", GC.GetTotalMemory(false)/1024);
				
				return 0;
			}
		}
		
		catch(Exception e)
		{
			Console.Write("Problem occurred at: ");
			Console.WriteLine(e.Source);
			Console.WriteLine(e.Message);
			return -1;
		}
	}
}
