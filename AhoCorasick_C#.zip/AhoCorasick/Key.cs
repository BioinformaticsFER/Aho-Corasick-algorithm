using System;

/*
 * This side class is used to define new type corresponding
 * to the type Tuple<int, char> (this is obligatory becuase Tuple is very
 * slow when compared with this class).
 * 
 * It is used to map a pair of (state, symbol) - values used by gotoFun 
 * and failure function
 * 
 * It contains three methods:
 *     - method Key
 *     - method Equals 
 *     - method GetHashCode
 */
public class Key
{
	int state1;
	char char1;
	
	/* This method stores (state, symbol) pairs */
	public Key(int i, char a)
	{
		state1 = i;
		char1 = a;
	}
	
	/* Overriden method used for compairing two objects of class Key */
	public override Boolean Equals(Object o)
	{
		if(this == o) 
			return true;
		if(!(o.GetType() ==  typeof(Key)))
			return false;
		
		Key key = (Key) o;
		return state1 == key.state1 && char1 == key.char1;
	}
	
	/*
	 * Overriden method digests the data stored in an instance of the class into 
	 * a single hash value (a 32-bit signed integer)
	 * 
	 * */
	public override int GetHashCode()
	{
		int result = state1;
		result = 31 * result + char1;
		return result;
	}
}
