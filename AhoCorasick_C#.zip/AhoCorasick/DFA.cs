using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

public class DFA
{
	private int newstate = 0;
	public Dictionary<Tuple<int, char>, int> g = new Dictionary<Tuple<int, char>, int>();
	public Dictionary<int, List<string>> output = new Dictionary<int, List<string>>{};
	public List<char> alphabet = new List<char>{};
	public Dictionary<int, int> f = new Dictionary<int, int>{};
	
	public void gotoFun (string[] keywords)
	{
		foreach(string word in keywords)
		{
			for(int i = 0; i < word.Length; i++)
			{
				if (!alphabet.Contains(word[i]))
				{
					alphabet.Add(word[i]);
				}
			}
			enter(word);
		}
		
		foreach(char symbol in alphabet)
		{
			Tuple<int, char> t1 = new Tuple<int, char>(0, symbol);
			
			if (!g.ContainsKey(t1))
			{
				g.Add(t1, 0);
			}
		}
	}
	
	public void enter (string key)
	{
		int state = 0;
		int j = 0;
		
		int len = key.Length;
		
		while(g.ContainsKey(new Tuple<int, char>(state, key[j])))
		{
			state = g[new Tuple<int, char>(state, key[j])];
			j++;
		}
		
		for(int i = j; i < len; i++)
		{
			newstate++;
			g.Add(new Tuple<int, char>(state, key[i]), newstate);
			state = newstate;
		}
		if (!output.ContainsKey(state))
		{
			output[state] = new List<string>();
		}
		output[state].Add(key);
	}
	
	public void failure ()
	{
		List<int> queue = new List<int>();
		
		foreach(var item in alphabet)
		{
			int s = 0;
			if (g[new Tuple<int, char>(0, item)] != 0)
			{
				s = g[new Tuple<int, char>(0, item)];
				queue.Add(s);
				f.Add(s, 0);
			}
		}
		
		while (queue.Count != 0)
		{
			int r = queue[0];
			queue.Remove(r);
			
			int s = 0;
			int counter = 0;
			
			foreach(var item in alphabet)
			{
				char a = item;
				
				if(g.ContainsKey(new Tuple<int, char>(r, a)))
				{
					s = g[new Tuple<int, char>(r, a)];
					queue.Add(s);
				}
				
				int state = f[r];
				
				while(!g.ContainsKey(new Tuple<int, char>(state, a)))
				{
					state = f[state];	
				}
				
				if(!f.ContainsKey(s))
					f.Add(s, g[new Tuple<int, char>(state, a)]);
				
				if(output.ContainsKey(f[s]) && counter == 0)
				{
					output[s].AddRange(output[f[s]]);
					counter++;
				}
			}
		}
	}
}