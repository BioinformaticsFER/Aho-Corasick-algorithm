using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

/*
 * Class DFA is side class used by class AhoCorasick.
 *
 * It's purpose is to build DFA using methods gotoFun, enter
 * and failure
 * 
 */
public class DFA
{
	private int newstate = 0;
	public Dictionary<Key, int> g = new Dictionary<Key, int>();
	public Dictionary<int, List<string>> output = new Dictionary<int, List<string>>{};
	public List<char> alphabet = new List<char>{};
	public Dictionary<int, int> f = new Dictionary<int, int>{};
	
	/* 
	 * Method gotoFun maps a pair consisting of a state and an input symbol
	 * into a transition state: g(state, a) = transition_state.
	 * 
	 * Trasitions are created based on all keywords.
	 * 
	 */
	public void gotoFun (string[] keywords)
	{
		foreach(string word in keywords)
		{
			for(int i = 0; i < word.Length; i++)
			{
				if (!alphabet.Contains(word[i]))
				{
					alphabet.Add(word[i]);
				}
			}
			enter(word);
		}
		
		foreach(char symbol in alphabet)
		{
			Key t1 = new Key(0, symbol);
			
			if (!g.ContainsKey(t1))
			{
				g.Add(t1, 0);
			}
		}
	}
	
	/* 
	 * Method enter is side method used by goto function
	 * 
	 * It constructs transition map (public variable g) and output map
	 * (public variable output)
	 * 
	 * */
	public void enter (string key)
	{
		int state = 0;
		int j = 0;
		
		int len = key.Length;
		
		// First find the longest key's prefix already defined 
		while(g.ContainsKey(new Key(state, key[j])))
		{
			state = g[new Key(state, key[j])];
			j++;
		}
		
		// Define transitions for the rest of key
		for(int i = j; i < len; i++)
		{
			newstate++;
			g.Add(new Key(state, key[i]), newstate);
			state = newstate;
		}
		
		// Output defines states in which certian keywords are found
		if (!output.ContainsKey(state))
		{
			output[state] = new List<string>();
		}
		output[state].Add(key);
	}
	
	/*
	 * Failure function maps a state into a state.
	 * 
	 * Failure function is called whenever goto function 
	 * doesn't have defined transition for certain (state, symbol)-pair.
	 * 
	 * Only initial state (state 0) doesn't have defined failure
	 * transition - initial state has transition back to itself for all
	 * undefined transitions (0, a)
	 * 
	 */
	public void failure ()
	{
		List<int> queue = new List<int>();
		
		//add all level-1 nodes to failure function
		foreach(var item in alphabet)
		{
			int s = 0;
			if (g[new Key(0, item)] != 0)
			{
				s = g[new Key(0, item)];
				queue.Add(s);
				f.Add(s, 0);
			}
		}
		
		//find for each node its failure function transition
		while (queue.Count != 0)
		{
			int r = queue[0];
			queue.Remove(r);
			
			int s = 1;
			int counter = 0;
			
			foreach(var item in alphabet)
			{
				char a = item;
				
				if(g.ContainsKey(new Key(r, a)))
				{
					s = g[new Key(r, a)];
					queue.Add(s);
				}
				
				int state = f[r];
				
				while(!g.ContainsKey(new Key(state, a)))
				{
					state = f[state];	
				}
				
				if(!f.ContainsKey(s))
					f.Add(s, g[new Key(state, a)]);
				
				if(output.ContainsKey(f[s]) && counter == 0)
				{
					output[s].AddRange(output[f[s]]);
					counter++;
				}
			}
		}
	}
}