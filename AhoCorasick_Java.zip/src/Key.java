/**
 * Side class that is used in transitionMap. This class stores pairs(state, input symbol).
 * Overridden methods equals and hashCode are used for comparing objects based on their attributes.
 */

public class Key {
	
	int state1;		//state in finite state machine
	char char1;		//input symbol
	
	public Key(int i, char a) {
		state1=i;
		char1=a;
	}
	
	/**
	 * Overridden method equals compares two objects of class Key based on their attributes.
	 * @param o
	 */
	@Override
    public boolean equals(Object o) {
		
        if (this == o) {
        	return true;
        }
        
        if (!(o instanceof Key)) {
        	return false;
        }
        
        Key key = (Key) o;
        return state1 == key.state1 && char1 == key.char1;
    }

	/**
	 * Overridden method hashCode digests the data stored in an instance of the class into
	 * a single hash value (a 32-bit signed integer).
	 */
    @Override
    public int hashCode() {
    	
        int result = state1;
        result = 31 * result + char1;
        return result;
    }	
}
