/*Side class that we use in transitionMap.
 * This class stores pairs (state, input symbol).
 */

public class Key {
	
	int state1;
	char char1;
	
	public Key(int i, char a) {
		state1=i;
		char1=a;
	}
	
}
