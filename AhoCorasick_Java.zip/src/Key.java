/*Side class that we use in transitionMap.
 * This class stores pairs (state, input symbol).
 */

public class Key {
	
	int state1;
	char char1;
	
	public Key(int i, char a) {
		state1=i;
		char1=a;
	}
	
	@Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Key)) return false;
        Key key = (Key) o;
        return state1 == key.state1 && char1 == key.char1;
    }

    @Override
    public int hashCode() {
        int result = state1;
        result = 31 * result + char1;
        return result;
    }
	
}
