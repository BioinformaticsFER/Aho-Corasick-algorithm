import java.lang.String;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Class DFA is used by main method for constructing finite state machine. It
 * returns transition map, output map, alphabet and failure map.	
 */
public class DFA {
	
	Map<Key,Integer> transitionMap = new LinkedHashMap<Key,Integer>();
	Map<Integer,List<String>> outputMap = new LinkedHashMap<Integer,List<String>>();	
	List<Character> alphabet = new ArrayList<Character>();
	Map<Integer,Integer> failureMap = new LinkedHashMap<Integer,Integer>();
	List<Integer> listOfStates = new ArrayList<Integer>();	//side list of states used for constructing failure map
	int newstate = 0;
	
	public DFA() {	
		
	}
	
	/**
	 * Method gotoFunction calls method enter for all input keywords. After that, 
	 * it completes constructing transition map in for loop. Transitions are created
	 * based on all keywords.
	 * @param keywords array of input keywords
	 */
	public void gotoFunction(String[] keywords) {
			
		for (String keyword: keywords)
	    {
			if (!keyword.isEmpty()) {
				enter(keyword);
			} 
	    }
			
		for (char a: alphabet) {
			
			/*
			 *For all input symbols where transitionMap (0,input symbol) -> fail, 
			 *put transitionMap (0,input symbol) -> 0. 
			 */	
			Key k1 = new Key(0, a);
			
			if (!transitionMap.containsKey(k1)) {
				transitionMap.put(k1, 0);
			}		
		}		
	}
	
	/**
	 * Method enter is a side method used by gotoFunction. It constructs transition map and 
	 * output map from keywords.
	 * @param keyword
	 */
	public void enter(String keyword) {
		
		for (int i = 0; i < keyword.length(); i++) {
			if (!alphabet.contains(keyword.charAt(i))) {
				alphabet.add(keyword.charAt(i));
			}
		}
			
		int state = 0;
		int j = 0;
		
		/*First find the longest keyword's prefix already defined*/ 
		Key k2 = new Key(state,keyword.charAt(j));	
		
		while (transitionMap.containsKey(k2)) {
			state = transitionMap.get(k2);
			j = j + 1;
			k2.state1 = state;
			k2.char1 = keyword.charAt(j);
		}
			
		/*Define transitions for the rest of the keyword*/
		for (int p = j; p < keyword.length(); p++) {
			newstate = newstate+1;
			Key k1 = new Key(state,keyword.charAt(p));
			transitionMap.put(k1, newstate);
			state = newstate;
		}
		
		List<String> listKeyWord = new ArrayList<String>();
		listKeyWord.add(keyword);
		outputMap.put(state, listKeyWord);			
	}
	
	/**
	 * Method failureFunction constructs failure map according to Aho-Corasick algorithm.
	 * Failure map is consulted when there is no defined transition for a certain pair (state,
	 * input symbol) in the transition map. Every state has its own failure state. Only start state (0)
	 * doesn't have defined failure transition - start state has transition back into 0 for all 
	 * undefined transitions (0,a).  
	 */
	public void failureFunction(){
		/**
		 * Starts with states s that have defined transitions (0, input symbol) -> s. Those states   
		 * have f(s) = 0, their failure state is start state 0. All failure functions for other states  
		 * are generated based on states that have smaller depth. 
		 * Depth(s) - number of transitions from 0 to s
		 */
		
		for (char ch: alphabet) {
			Key k2 = new Key(0,ch);
			int s = transitionMap.get(k2);
			
			if (s !=0) {
				listOfStates.add(s);
				failureMap.put(s,0);
			}		
		}
		
		while (!listOfStates.isEmpty()) {
			int state = listOfStates.get(0);
			listOfStates.remove(0);
			
			for (char a: alphabet) {	
				Key k1 = new Key(state, a);
				
				if (transitionMap.containsKey(k1)) {	
					int value1 = transitionMap.get(k1);
					listOfStates.add(value1);
					int state1 = failureMap.get(state);
					
					while (!transitionMap.containsKey(new Key(state1,a))) {
						state1=failureMap.get(state1);
					}
					
					Key k = new Key(state1,a);
					failureMap.put(value1, transitionMap.get(k));
					
					/*In output map, every state, except its own keyword, now gets keyword of its failure state.*/
					List<String> list1 = outputMap.get(value1);
					List<String> list2 = outputMap.get(transitionMap.get(k));
					
					if (list1 != null && list2 != null) {
						list1.addAll(list2);
					} else if (list1 == null && list2 != null) {
						list1 = list2;
					}
				}
			}			
		}
	}
}
