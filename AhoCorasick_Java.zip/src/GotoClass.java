import java.lang.String;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/*Class GotoClass and its methods map a pair (old state, input symbol) 
 * with a new state. It is stored in transition map like:
 * transitionMap (old state, input symbol) -> new state
 * Transitions are created based on all keywords. 		
 */

public class GotoClass {

	int newstate=0;
	Map<Key,Integer> transitionMap=new LinkedHashMap<Key,Integer>();	//Key is an object where pair(old state, input symbol) is stored
	Map<Integer,List<String>> outputMap = new LinkedHashMap<Integer,List<String>>();	
	/*outputMap defines states in which certain keywords are found*/
	public List<Character> alphabet = new ArrayList<Character>();
	public List<Key> keyList = new ArrayList<Key>();	//list of all keys in transitionMap
	Map<Integer,Integer> failureMap =new LinkedHashMap<Integer,Integer>();
	
	public GotoClass(){
		
	}
	
	
	public void gotoFunction(String[] keyWords){
			
		for (String keyWord: keyWords)
	    {
	      enter(keyWord);
	    }
		
		for(char a: alphabet){
			
			/*For all input symbols where  transitionMap(0,input symbol)->fail, put transitionMap(0,input symbol) -> 0 */
			int var=0;
			Key k1=new Key(0,a);
			for(Key k3: keyList){
				if(k3.state1==0){
					if(k3.char1==k1.char1){
						var=1;
						break;
					}
				}
			}
			
			if(var==0){
				transitionMap.put(k1,0);
			}
			
		}
		
		/*for (Key key : transitionMap.keySet()) {
			System.out.println("Key : " + key.state1 + key.char1 + " Value : "
				+ transitionMap.get(key));
		}*/
			
	}
	
	//Method enter is a side method used by gotoFunction
	public void enter(String keyword){
		
		for(int i=0;i<keyword.length();i++){
			if(!alphabet.contains(keyword.charAt(i))){
				alphabet.add(keyword.charAt(i));
			}
		}
			
		int state=0;
		int j=0;
		
		//First find the longest keyword's prefix already defined 
		Key k2 = new Key(state,keyword.charAt(j));
		for(Key k3: keyList){
			if(k3.state1==k2.state1 && k3.char1==k2.char1){
				state = transitionMap.get(k3);
				j=j+1;
				k2.state1=state;
				k2.char1=keyword.charAt(j);
			}
		}
		
		//Define transitions for the rest of keyword
		for(int p=j;p<keyword.length();p++){
			
			newstate=newstate+1;
			Key k1 = new Key(state,keyword.charAt(p));
			transitionMap.put(k1, newstate);
			keyList.add(k1);
			state=newstate;
			
		}
		
		List<String> listKeyWord = new ArrayList<String>();
		listKeyWord.add(keyword);
		outputMap.put(state, listKeyWord);	
		
	}
	
	public void callFailure(){
		Failure f1 = new Failure(transitionMap, outputMap, alphabet,failureMap);
		f1.failureFunction();
	}
	
}
