import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.List;
import java.util.Map;


public class Start {

	public static void main(String[] args) throws IOException{
		
		int kib=1024;
		Runtime runtime = Runtime.getRuntime();	//used memory
		
		String[] keywords=null;
		String text=null;
		File keywordsFile = null;
		File textFile = null;
		long startTime0 = System.currentTimeMillis();	//measuring time
		if(args.length==2){

			try {
				keywordsFile = new File(args[0]);
				BufferedReader bufferedReader = new BufferedReader(new FileReader(keywordsFile));
				StringBuffer stringBuffer = new StringBuffer();
				String line = null;
				while((line=bufferedReader.readLine())!=null){
					stringBuffer.append(line);
				}
				keywords = stringBuffer.toString().split(",");
			} catch (FileNotFoundException e) {
				System.err.println("File with keywords does not exist!");
				e.printStackTrace();
				System.exit(-1);
			}
			
			try{
				textFile = new File(args[1]);
				BufferedReader bufferedReader = new BufferedReader(new FileReader(textFile));
				StringBuffer stringBuffer = new StringBuffer();
				String line = null;
				while((line=bufferedReader.readLine())!=null){
					stringBuffer.append(line);
					//stringBuffer.append('\n');
				}
				text = stringBuffer.toString();
				} catch(FileNotFoundException e){
				System.err.println("File with input text does not exist!");
				e.printStackTrace();
				System.exit(-1);
				}
		}
		else{
			System.out.println("Invalid arguments count:" + args.length);
			System.exit(-1);
		}
		System.out.println((int)textFile.length());
		
		long currentTime0 = System.currentTimeMillis() - startTime0;
		System.out.println("Loading files done in " + currentTime0 + " ms");
		
		//Constructing a DFA for pattern matching from the set of keywords
		GotoClass goto1 = new GotoClass();
		
		long startTime1 = System.currentTimeMillis();
		goto1.gotoFunction(keywords);
		goto1.callFailure();
		Map<Key,Integer> transitionMap = goto1.transitionMap;
		Map<Integer,List<String>> outputMap = goto1.outputMap;
		Map<Integer,Integer> failureMap =goto1.failureMap;
		List<Character> alphabet=goto1.alphabet;
		
		long currentTime1 = System.currentTimeMillis() - startTime1;
		System.out.println("Construction of DFA done in " + currentTime1 + " ms");
		
		//Finding all occurrences of keywords in text using DFA  
		long startTime2 = System.currentTimeMillis();
		PrintWriter writer = new PrintWriter("output", "UTF-8");
		int state=0;
				
		for(int i=0; i < text.length(); i++){
			if(i%100000==0){
				System.out.println(i);
			}
			char a = text.charAt(i);
			int var=0;
			
			for(Key key: transitionMap.keySet()){
				
				if(key.state1==state && key.char1==a){
					
					state=transitionMap.get(key);
					var=1;
					if(outputMap.containsKey(state)){
						
						for(String s: outputMap.get(state)){
							writer.print("index: ");
							writer.format("%7d",(i-s.length()+1));
							writer.println(" => keyword: " + s);	
						}
						
					}
					break;
				}
			}
			
			if(var==0){
				
				if(!alphabet.contains(a)){
					alphabet.add(a);
					Key key1 = new Key(0, a);
					transitionMap.put(key1, 0);
				}
				
				if(state!=0){
					
					int foundState=0;			
					while(foundState==0){
						state=failureMap.get(state);
						for(Key key2: transitionMap.keySet()){
							if(key2.state1==state && key2.char1==a){
								foundState=1;
								state=transitionMap.get(key2);
								break;
							}
						}
						
					}
				}
			}
			
		}
		
		writer.close();
		long currentTime2 = System.currentTimeMillis() - startTime2;
		System.out.println("Finding all keywords in text done in " + currentTime2 + " ms");
		
		System.out.println("Total memory used: " + (runtime.totalMemory() - runtime.freeMemory())/kib + " KiB");
		
	}

}
