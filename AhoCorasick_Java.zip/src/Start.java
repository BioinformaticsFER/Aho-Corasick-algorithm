/*
 *  %w% %E% Antonio Zemunik
 *  
 *  This software is based on Aho-Corasick string searching algorithm which constructs a 
 *  finite state machine (DFA) based on input keywords. The algorithm locates elements of a finite set
 *  of strings within an input text. So, the final result shows indexes where input keywords are 
 *  located in input text.
 *  In this project, the software is used in Bioinformatics.  
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.PrintWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Class Start contains main method. Also, it has transition map, output map, failure map and list
 * of characters named alphabet. Transition map and failure map are used in finite state machine and
 * output map is used for printing (writing in output file).
 */
public class Start {

	/**
	 * Main method reads input keywords and text from two files. It produces both Terminal and file 
	 * outputs: Terminal - performance (time spent constructing DFA, time spent locating all 
	 * keywords, memory usage), file - keywords that were located in text and their indexes.
	 * @param args	file with input keywords and file with input text
	 * @throws IOException
	 */
	public static void main(String[] args) throws IOException {
		/**
		 * After reading keywords file, main constructs finite state machine using DFA class. 
		 * Then, reading text line by line, locates keywords in text.
		 */
		
		Runtime runtime = Runtime.getRuntime();		//memory used by program
		String[] keywords = null;
		String text = null;
		File keywordsFile = null;
		File textFile = null;
		BufferedReader bufferedReader = null;
		
		/**transitionMap stores pairs (old state, input symbol) -> new state*/
		Map<Key,Integer> transitionMap = new LinkedHashMap<Key,Integer>();
		
		/**outputMap defines states in which certain keywords are found*/
		Map<Integer,List<String>> outputMap = new LinkedHashMap<Integer,List<String>>();	
		
		/**alphabet stores all characters from keywords*/
		List<Character> alphabet = new ArrayList<Character>();
		
		/**failureMap stores pairs state -> failure state according to Aho-Corasick algorithm*/
		Map<Integer,Integer> failureMap = new LinkedHashMap<Integer,Integer>();
		
		if (args.length == 2) {
			try {
				keywordsFile = new File(args[0]);
				bufferedReader = new BufferedReader(new FileReader(keywordsFile));
				StringBuffer stringBuffer = new StringBuffer();
				String line = null;
				line = bufferedReader.readLine();
				stringBuffer.append(line);
				keywords = stringBuffer.toString().split(",");
			} catch (FileNotFoundException e) {
				System.err.println("File with keywords does not exist!");
				System.exit(-1);
			}
			
			try {
				textFile = new File(args[1]);
				bufferedReader = new BufferedReader(new FileReader(textFile));
			} catch (FileNotFoundException e) {
				System.err.println("File with input text does not exist!");
				System.exit(-1);
			}
		} else {
			System.err.println("Invalid number of arguments: " + args.length);
			System.err.println("Required number of arguments: 2");
			System.exit(-1);
		}
		
		/*Constructing a DFA for pattern matching from the set of keywords*/
		long startTime1 = System.nanoTime();		//measuring time
		DFA dfa1 = new DFA();
		dfa1.gotoFunction(keywords);
		dfa1.failureFunction();
		transitionMap = dfa1.transitionMap;
		outputMap = dfa1.outputMap;
		alphabet=dfa1.alphabet;
		failureMap = dfa1.failureMap;
		long currentTime1 = System.nanoTime() - startTime1;
		System.out.println("Construction of DFA done in " + currentTime1/1000000.0 + " ms");
		
		/*Finding all occurrences of keywords in text using DFA*/  
		long startTime2 = System.nanoTime();
		
		/*Locations of keywords in the text will be written in a file named output*/
		PrintWriter writer = new PrintWriter("output", "UTF-8");	
		int state = 0;	//start state
		int position = 0;
		
		/*
		 * Reading input text line by line. This way, instead of working with whole 
		 * text at once, we process only one line at a time (send it to constructed DFA).
		 * It saves a lot of memory. Speaking of time, it is the same.
		 */
		while ((text = bufferedReader.readLine()) != null) {	
			for (int i = 0; i < text.length(); i++){
				char a = text.charAt(i);
				int var = 0;
				Key key = new Key(state, a);			
					
				if (transitionMap.containsKey(key)) {			
					state=transitionMap.get(key);
					var=1;
					
					if (outputMap.containsKey(state)) {	
						for (String s: outputMap.get(state)) {
							writer.print("index: ");
							writer.format("%7d", (position + (i-s.length()+1)));
							writer.println("  =>  keyword: " + s);	
						}					
					}			
				}
								
				if (var == 0) {		
					if (!alphabet.contains(a)) {
						
						/*Add to alphabet all characters that were not found in keywords*/
						alphabet.add(a);
						Key key1 = new Key(0, a);
						transitionMap.put(key1, 0);
					}
					
					if (state != 0) {		/*if state == 0, algorithm stays in state 0*/
						int foundState = 0;	
						
						while (foundState == 0) {
							state=failureMap.get(state);
							key.state1 = state;
							
							if (transitionMap.containsKey(key)) {
								foundState = 1;
								state = transitionMap.get(key);
								break;
							}			
						}
					}
				}			
			}
			position = position + text.length();
		}
		writer.close();
		long currentTime2 = System.nanoTime() - startTime2;
		System.out.println("Finding all keywords in text done in " + currentTime2/1000000.0 + " ms");
		
		int kib=1024;
		System.out.println("Total memory used: " + (runtime.totalMemory() - runtime.freeMemory())/kib + " KiB");	
	}
}
