import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/*Class Failure with its failureFunction maps a state into a state.
 * It is stored in failure map like: 
 * failureMap(state)->state
 * It is used when there is no defined pair (state,input symbol) in transitionMap.
 * That means: for current state and input symbol, DFA doesn't know the transition.
 * So, it is necessary to check failure state for current state.
 * Every state has its failure state, except start state (0).
 * Start state has transition back into 0 for all undefined transitions (0, input symbol).
 */

public class Failure {
	
	Map<Key,Integer> transitionMap=new LinkedHashMap<Key,Integer>(); 	
	Map<Integer,List<String>> outputMap = new LinkedHashMap<Integer,List<String>>();	
	public List<Character> alphabet = new ArrayList<Character>();
	List<Integer> listOfStates = new ArrayList<Integer>();	//help list of states used for constructing failure map
	Map<Integer,Integer> failureMap =new LinkedHashMap<Integer,Integer>();
	
	public Failure(){
		
	}
	
	public Failure(Map<Key,Integer> map1, Map<Integer,List<String>> map2, List<Character> alph, Map<Integer,Integer> failureMap){
		this.transitionMap=map1;
		this.outputMap=map2;
		this.alphabet=alph;
		this.failureMap=failureMap;
	}
	
	public void failureFunction(){
		
		for (Key key : transitionMap.keySet()){
			
			int state=transitionMap.get(key);
			if(key.state1==0 && state!=0){
				listOfStates.add(state);
				failureMap.put(state,0 );
			}
		}
		
		while(!listOfStates.isEmpty()){
			
			
			int state = listOfStates.get(0);
			listOfStates.remove(0);
			for(char a: alphabet){
				
				for(Key key: transitionMap.keySet()){
					if(key.state1==state && key.char1==a){
						int value1 = transitionMap.get(key);
						listOfStates.add(value1);
						int state1 = failureMap.get(state);
						int found=0;
						int counter=0;
						
						while(found==0){
							
							if(counter>0){
								state1=failureMap.get(state1);
							}
							counter++;
							
							for(Key key1:transitionMap.keySet()){
								
								if(key1.state1==state1 && key1.char1==a){
									found=1;
									int value2 = transitionMap.get(key1);
									failureMap.put(value1, value2);
									/*Every state in output map has its own output + output of its failure state. */
									List<String> list1 = outputMap.get(value1);
									List<String> list2 = outputMap.get(value2);
									if(list1!=null && list2!=null){
										list1.addAll(list2);
									}
									else if(list1==null && list2!=null){
										list1=list2;
									}
									
									break;
								}
							}							
						}
					}
				}
			}
				
		}
		
		/*for(int a: failureMap.keySet()){
			System.out.println(a + "->" + failureMap.get(a));
		}*/
		
		/*for(int a: outputMap.keySet()){
					
			System.out.print(a);
			for(String s: outputMap.get(a)){
				System.out.print(" " + s);
			}
			System.out.println();
					
		}*/
		
	}
}
